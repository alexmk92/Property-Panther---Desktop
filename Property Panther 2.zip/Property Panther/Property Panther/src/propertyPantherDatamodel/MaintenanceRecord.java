/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;
import java.util.ArrayList;
import static propertyPantherDatamodel.MaintenanceStatus.PENDING;

/**
 *
 * @author Tom
 */
public class MaintenanceRecord implements ISubject, IObserver, Serializable {

    private ArrayList<Maintenance> maintenance;
    private transient ArrayList<IObserver> observerList;

    public ArrayList<IObserver> getObservers()
    {
        ArrayList<IObserver> arlResult = new ArrayList<>();
        for (IObserver currObserver : observerList)
        {
            arlResult.add(currObserver);
        }
        return arlResult;
    }
    
    // Default constructor (empty).
    public MaintenanceRecord() {
        this.maintenance = new ArrayList<>();
        this.observerList = new ArrayList<>();
    }

    // Adding a maintenance record to the ArrayList maintenance.
    public void addRecord(Maintenance newMain) {

        if (null != newMain) {
            this.maintenance.add(newMain);
            newMain.registerObserver(this);
            this.notifyObservers();
        }
    }

    // retrieves the record at the location of the index.
    public Maintenance getRecordAt(int index) {
        Maintenance result = null;

        if (index >= 0 && index < this.maintenance.size()) {
            result = this.maintenance.get(index);
        }
        return result;
    }

    public Maintenance removerMainRequest(int index){
         
         Maintenance result = null;
        if(index >= 0 && index < this.maintenance.size()){
            result = this.maintenance.remove(index);
            result.removeObserver(this);
            this.notifyObservers();
        }
        return result;
     }
    
    // approves the record at the index location.
    public void approveRecord(int index) {

        Maintenance targetMain = this.getRecordAt(index);

        if (null != targetMain) {
            switch (targetMain.getMainStatus()) {
                case PENDING:
                    targetMain.approved();
                    break;

                default:
                    targetMain.approved();
            }
        }
    }

    // Decline the request at the index location.
    public void declineRecord(int index) {

        Maintenance targetMain = this.getRecordAt(index);

        if (null != targetMain) {
            switch (targetMain.getMainStatus()) {
                case PENDING:
                    targetMain.declined();
                    break;
            }
        }
    }
    
    public void clearAll(){
        for (Maintenance currMain : this.maintenance){
            currMain.removeObserver(this);
        }
        
        this.maintenance.clear();
        this.notifyObservers();
    }

    public int size(){
        return this.maintenance.size();
    }
    
    
    @Override
    public void update() {
        this.notifyObservers();
    }

    @Override
    public Boolean registerObserver(IObserver o) {
        Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
        Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    @Override
    public void notifyObservers() {
        if(null != this.observerList && 0 < this.observerList.size()){
            for(IObserver currObserver : this.observerList){
                currObserver.update();
            }
        }
    }
}
