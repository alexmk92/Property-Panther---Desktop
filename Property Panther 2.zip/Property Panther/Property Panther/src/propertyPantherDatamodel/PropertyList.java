/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public class PropertyList implements ISubject, IObserver, Serializable{

    private ArrayList<Property> propList = new ArrayList();
    
     private transient ArrayList<IObserver> observerList;
    
     
     public ArrayList<IObserver> getObservers()
    {
        ArrayList<IObserver> arlResult = new ArrayList<>();
        for (IObserver currObserver : observerList)
        {
            arlResult.add(currObserver);
        }
        return arlResult;
    }
    
    public PropertyList(){
        this.propList = new ArrayList<>();
    }
    
    
    public void addProperty(Property newProperty){
        if(null != newProperty){
            this.propList.add(newProperty);
            newProperty.registerObserver(this);
            this.notifyObservers();
        }
    }
    
    
    public Property removeProperty(int index){
        Property result = null;
        if(index >= 0 && index < this.propList.size()){
            result = this.propList.remove(index);
            result.removeObserver(this);
            this.notifyObservers();
        }     
        return result;
    }
    
    public Property getPropertyAt(int index){
        Property result = null;
        if(index >= 0 && index < this.propList.size()){
            result = this.propList.get(index);
        }
        
        return result;
    }
    
    public int size(){
        return this.propList.size();
    }
    
    
    @Override
    public void update() {
        this.notifyObservers();
    }

    @Override
    public Boolean registerObserver(IObserver o) {
        Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
         Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    @Override
    public void notifyObservers() {
        if(null != this.observerList && 0 < this.observerList.size()){
            for(IObserver currObserver : this.observerList){
                currObserver.update();
            }
        }
    }
    
}
