/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package propertyPantherDatamodel;

/**
 *
 * @author User
 */
public enum UserPermission {
    
    USER,
    ADMIN;
    
    
    @Override
    public String toString() {
        String result = "UNKNOWN";
        switch(this){
            case USER:
                result = "USER";
                break;
            case ADMIN:
                result = "ADMIN";
                break;
        }
        return result;
    }
}
