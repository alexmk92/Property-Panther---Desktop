/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Tom
 */
public class Request implements ISubject {

    private MaintenanceStatus status;
    private Date issueDate;
    private String email;
    private String request;
    private transient ArrayList<IObserver> observerList;

    public Request() {

        this.issueDate = new Date();
        this.email = "email not present";
        this.request = "";
        this.status = MaintenanceStatus.PENDING;
        this.observerList = new ArrayList<>();
    }

    public Request(Date issueDate, String email, String request) {

        this.issueDate = issueDate;
        this.email = email;
        this.request = request;
        this.observerList = new ArrayList<>();
    }

    public void approved() {

        this.status = MaintenanceStatus.APPROVED;
        this.notifyObservers();
    }

    public void declined() {

        this.status = MaintenanceStatus.DECLINED;
        this.notifyObservers();
    }

    
    // Setters and getters
    public MaintenanceStatus getStatus() {
        return status;
    }

    public void setStatus(MaintenanceStatus status) {
        this.status = status;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    @Override
    public Boolean registerObserver(IObserver o) {
        Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
        Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    @Override
    public void notifyObservers() {
        if(null != this.observerList && 0 < this.observerList.size()){
            for(IObserver currObserver : this.observerList){
                currObserver.update();
            }
        }
    }
    
    
}
