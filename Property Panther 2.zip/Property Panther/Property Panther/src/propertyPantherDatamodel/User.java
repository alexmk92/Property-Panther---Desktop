/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public class User implements ISubject, Serializable{
    
    protected String title;
    protected String forename;
    protected String surname;
    protected String email;
    protected String number;
    protected String address;
    private UserPermission permission;
    private Property property;
    private Room room;
    
    private transient ArrayList<IObserver> observerList;
    
    public User() {
        this.title = "";
        this.forename = "";
        this.surname = "";
        this.email = "";
        this.number = "";
        this.address = "";
    }
    
    public User(String title, String forename, String surname, String email, String number, String address){
        this.title = title;
        this.forename = forename;
        this.surname = surname;
        this.email = email;
        this.number = number;
        this.address = address;
        this.permission = UserPermission.USER;
    }
    
    public User(String title, String forename, String surname, String email, String number, String address, 
                                                   Property property, Room  room){
        this.title = title;
        this.forename = forename;
        this.surname = surname;
        this.email = email;
        this.number = number;
        this.address = address;
        this.permission = UserPermission.USER;
        this.room = room;
        // sets status to occupied if the user has a room.
        this.room.occupied();
        
    }
    
    // sets permission to admin
    public void admin(){
        this.permission = UserPermission.ADMIN;
    }
    
    
    public String getName(){
        String result = "UNKNOWN";
        
        if(null != this.forename && null != this.surname){
            result = this.surname + ", " + this.forename;
        }
        return result;
    }
    
    public String getAllDetails(){
        String result = "UNKNOWN";
        
        if(null != this.forename && null != this.surname && null != this.email && null != this.number){
            result = this.surname + ", " + this.forename + "email: " + this.email + "Telephone Number: " + this.number;
        }
        return result;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Override
    public Boolean registerObserver(IObserver o) {
         Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
        Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    
    // this wont work, coomes up with errors if i add the code needed.
    @Override
    public void notifyObservers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
}
