/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;
import java.util.ArrayList;
import static propertyPantherDatamodel.MaintenanceStatus.PENDING;

/**
 *
 * @author Tom
 */
public class RequestRecord implements ISubject, IObserver, Serializable {

    private ArrayList<Request> genRequest;
    private transient ArrayList<IObserver> observerList;
   
    
    public ArrayList<IObserver> getObservers()
    {
        ArrayList<IObserver> arlResult = new ArrayList<>();
        for (IObserver currObserver : observerList)
        {
            arlResult.add(currObserver);
        }
        return arlResult;
    }
    
    
    public RequestRecord(){
        this.genRequest = new ArrayList<>();
    }
    
    public void addRequest(Request newReq) {

        if (null != newReq) {
            this.genRequest.add(newReq);
            newReq.registerObserver(this);
        }
    }
    
    public Request getRecordAt(int index) {
        Request result = null;

        if (index >= 0 && index < this.genRequest.size()) {
            result = this.genRequest.get(index);
        }
        return result;
    }
    
    public Request removeRequest(int index){
         
         Request result = null;
        if(index >= 0 && index < this.genRequest.size()){
            result = this.genRequest.remove(index);
            result.removeObserver(this);
            this.notifyObservers();
        }
        return result;
     }
    
    public void approveRequest(int index) {

        Request targetRequest = this.getRecordAt(index);

        if (null != targetRequest) {
            switch (targetRequest.getStatus()) {
                case PENDING:
                    targetRequest.approved();
                    break;

                default:
                    targetRequest.approved();
            }
        }
    }
    
    
     public void declineRecord(int index) {

        Request targetRequest = this.getRecordAt(index);

        if (null != targetRequest) {
            switch (targetRequest.getStatus()) {
                case PENDING:
                    targetRequest.declined();
                    break;
            }
        }
    }
    
     
     public void clearAll(){
        for (Request currMain : this.genRequest){
            currMain.removeObserver(this);
        }
        this.genRequest.clear();       
        this.notifyObservers();
    }

    public int size(){
        return this.genRequest.size();
    }
    
    @Override
    public void update() {
        this.notifyObservers();
    }

    @Override
    public Boolean registerObserver(IObserver o) {
        Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
        Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    @Override
    public void notifyObservers() {
       if(null != this.observerList && 0 < this.observerList.size()){
            for(IObserver currObserver : this.observerList){
                currObserver.update();
            }
        }
    }
    
}
