/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Tom
 */
public class Maintenance implements ISubject{

    private MaintenanceStatus mainStatus;
    private Date issueDate;
    private String Address;
    private String additionNotes;
    private transient ArrayList<IObserver> observerList;

    // Empty constructor, not sure if this is needed.
    public Maintenance() {

        this.issueDate = new Date();
        this.Address = "No Address Given";
        this.mainStatus = MaintenanceStatus.PENDING;
        this.additionNotes = "";
        this.observerList = new ArrayList<>();

    }

    // Creating a maintenance request retrieved form the user when no additional notes are given. Sets the status to pending.
    public Maintenance(Date issueDate, String address, MaintenanceStatus mainStatus) {

        this.issueDate = issueDate;
        this.Address = address;
        this.mainStatus = MaintenanceStatus.PENDING;

    }

    // creates maintenance request if additoional notes are given.
    public Maintenance(Date issueDate, String address, MaintenanceStatus mainStatus, String notes) {

        this.issueDate = issueDate;
        this.Address = address;
        this.mainStatus = MaintenanceStatus.PENDING;
        this.additionNotes = notes;

    }

    // Sets the maintenance status to 'APPROVED'.
    public void approved() {

        this.mainStatus = MaintenanceStatus.APPROVED;
        this.notifyObservers();
    }

    //Sets the maintenance status to 'DECLINED'.
    public void declined() {

        this.mainStatus = MaintenanceStatus.DECLINED;
        this.notifyObservers();
    }

    //Resets the status to default 'PENDING'.
    public void reset() {

        this.mainStatus = MaintenanceStatus.PENDING;
        this.notifyObservers();
    }

    // Setters and Getters. Not sure if these are needed.
    public MaintenanceStatus getMainStatus() {
        return mainStatus;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
        this.notifyObservers();
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
        this.notifyObservers();
    }

    public String getAdditionNotes() {
        return additionNotes;
    }

    public void setAdditionNotes(String additionNotes) {
        this.additionNotes = additionNotes;
        this.notifyObservers();
    }

    @Override
    public Boolean registerObserver(IObserver o) {
        Boolean result = false;
        if (null != o) {
            if (!this.observerList.contains(o)) {
                result = this.observerList.add(o);
            }
        }
        return result;
    }

    @Override
    public Boolean removeObserver(IObserver o) {
       Boolean result = false;
        if(null != o){
            result = this.observerList.remove(o);
        }
        return result;
    }

    @Override
    public void notifyObservers() {
       if(null != this.observerList && 0 < this.observerList.size()){
            for(IObserver currObserver : this.observerList){
                currObserver.update();
            }
        }
    }
}
