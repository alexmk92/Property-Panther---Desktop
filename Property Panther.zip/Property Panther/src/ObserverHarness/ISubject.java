/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ObserverHarness;

/**
 *
 * @author Tom
 */
public interface ISubject {
    
     Boolean registerObserver(IObserver o);
     
     Boolean removeObserver(IObserver o);
     
     void notifyObservers();
}
