/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import ObserverHarness.IObserver;
import ObserverHarness.SubjectActions;
import java.io.Serializable;
import java.util.ArrayList;
import static propertyPantherDatamodel.MaintenanceStatus.PENDING;

/**
 *
 * @author Tom
 */
public class RequestRecord implements IObserver, Serializable {

    private ArrayList<Request> genRequest;
    private SubjectActions subject = new SubjectActions();
    
    public RequestRecord(){
        this.genRequest = new ArrayList<>();
    }
    
    public void addRequest(Request newReq) {

        if (null != newReq) {
            this.genRequest.add(newReq);
            subject.registerObserver(this);
            subject.notifyObservers();
        }
    }
    
    public Request getRecordAt(int index) {
        Request result = null;

        if (index >= 0 && index < this.genRequest.size()) {
            result = this.genRequest.get(index);
        }
        return result;
    }
    
    public Request removeRequest(int index){
         
         Request result = null;
        if(index >= 0 && index < this.genRequest.size()){
            result = this.genRequest.remove(index);
            this.subject.removeObserver(this);
            this.subject.notifyObservers();
        }
        return result;
     }
    
    public void approveRequest(int index) {

        Request targetRequest = this.getRecordAt(index);

        if (null != targetRequest) {
            switch (targetRequest.getStatus()) {
                case PENDING:
                    targetRequest.approved();
                    break;

                default:
                    targetRequest.approved();
            }
        }
    }
    
    
     public void declineRecord(int index) {

        Request targetRequest = this.getRecordAt(index);

        if (null != targetRequest) {
            switch (targetRequest.getStatus()) {
                case PENDING:
                    targetRequest.declined();
                    break;
            }
        }
    }
    
     
     public void clearAll(){
        
        this.genRequest.clear();
        subject.removeObserver(this);
        subject.notifyObservers();
    }

    public int size(){
        return this.genRequest.size();
    }
    
    @Override
    public void update() {
        subject.notifyObservers();
    }
    
}
