/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;

/**
 *
 * @author Tom
 * 
 */
public enum PropertyStatus implements Serializable{
    
    VACANT,
    PENDING,
    TAKEN;
    
    
    @Override
    public String toString() {
        String result = "UNKNOWN";
        switch(this){
            case VACANT:
                result = "VACANT";
                break;
            case PENDING:
                result = "PENDING";
                break;
            case TAKEN:
                result = "TAKEN";
                break;
        }
        return result;
    }
}
