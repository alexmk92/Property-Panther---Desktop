/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;

/**
 *
 * @author Tom
 */
public enum MaintenanceStatus implements Serializable{
    
    APPROVED,
    PENDING,
    DECLINED;
    
    @Override
    public String toString() {
        String result = "UNKNOWN";
        switch(this){
            case APPROVED:
                result = "APPROVED";
                break;
            case PENDING:
                result = "PENDING";
                break;
            case DECLINED:
                result = "DELCINED";
                break;
        }
        return result;
    }
}
