/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import ObserverHarness.IObserver;
import ObserverHarness.SubjectActions;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public class UserList implements IObserver, Serializable {
    
     private ArrayList<User> list = new ArrayList();
    
     private SubjectActions subject = new SubjectActions();
     
     // empty constructor
     public UserList(){     
         this.list = new ArrayList<>();
     }
     
     
     public void addStaff(User newUser){
        if(null != newUser){
            this.list.add(newUser);
            this.subject.registerObserver(this);
            this.subject.notifyObservers();
        }
    }

     public User removerUser(int index){      
         User result = null;
        if(index >= 0 && index < this.list.size()){
            result = this.list.remove(index);
            this.subject.removeObserver(this);
            this.subject.notifyObservers();
        }
        return result;
     }
     
     
     // Not sure if we need this function
   /* public String[] getAllUsers(){
        String[] result = new String[this.list.size()];
        for(int i = 0; i < this.list.size(); i++){
            User record = this.list.get(i);
            if(null != record){
                result[i] = record.getName();
            }
        }
        return result;
    }  */
     
     
    public User getUserAt(int index){
        User result = null;
        if(index >= 0 && index < this.list.size()){
            result = this.list.get(index);
        }
        return result;
    } 
     
    
    public int size(){
        return this.list.size();
    }
    
     
    @Override
    public void update() {
        subject.notifyObservers();
    }
     
     
     
     
    
}
