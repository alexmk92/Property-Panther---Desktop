/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import ObserverHarness.IObserver;
import ObserverHarness.SubjectActions;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Tom
 */
public class PropertyList implements IObserver, Serializable{

    private ArrayList<Property> propList = new ArrayList();
    
    private SubjectActions subject = new SubjectActions();
    
    
    public PropertyList(){
        this.propList = new ArrayList<>();
    }
    
    
    public void addProperty(Property newProperty){
        if(null != newProperty){
            this.propList.add(newProperty);
            this.subject.registerObserver(this);
            this.subject.notifyObservers();
        }
    }
    
    
    public Property removeProperty(int index){
        Property result = null;
        if(index >= 0 && index < this.propList.size()){
            result = this.propList.remove(index);
            this.subject.removeObserver(this);
            this.subject.notifyObservers();
        }     
        return result;
    }
    
    public Property getPropertyAt(int index){
        Property result = null;
        if(index >= 0 && index < this.propList.size()){
            result = this.propList.get(index);
        }
        
        return result;
    }
    
    public int size(){
        return this.propList.size();
    }
    
    
    @Override
    public void update() {
        subject.notifyObservers();
    }
    
}
