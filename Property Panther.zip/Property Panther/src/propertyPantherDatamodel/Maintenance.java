/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import ObserverHarness.SubjectActions;
import java.util.Date;

/**
 *
 * @author Tom
 */
public class Maintenance {

    private MaintenanceStatus mainStatus;
    private Date issueDate;
    private String Address;
    private String additionNotes;
    private SubjectActions subject = new SubjectActions();

    // Empty constructor, not sure if this is needed.
    public Maintenance() {

        this.issueDate = new Date();
        this.Address = "No Address Given";
        this.mainStatus = MaintenanceStatus.PENDING;
        this.additionNotes = "";

    }

    // Creating a maintenance request retrieved form the user when no additional notes are given. Sets the status to pending.
    public Maintenance(Date issueDate, String address, MaintenanceStatus mainStatus) {

        this.issueDate = issueDate;
        this.Address = address;
        this.mainStatus = MaintenanceStatus.PENDING;

    }

    // creates maintenance request if additoional notes are given.
    public Maintenance(Date issueDate, String address, MaintenanceStatus mainStatus, String notes) {

        this.issueDate = issueDate;
        this.Address = address;
        this.mainStatus = MaintenanceStatus.PENDING;
        this.additionNotes = notes;

    }

    // Sets the maintenance status to 'APPROVED'.
    public void approved() {

        this.mainStatus = MaintenanceStatus.APPROVED;
        subject.notifyObservers();
    }

    //Sets the maintenance status to 'DECLINED'.
    public void declined() {

        this.mainStatus = MaintenanceStatus.DECLINED;
        subject.notifyObservers();
    }

    //Resets the status to default 'PENDING'.
    public void reset() {

        this.mainStatus = MaintenanceStatus.PENDING;
        subject.notifyObservers();
    }

    // Setters and Getters. Not sure if these are needed.
    public MaintenanceStatus getMainStatus() {
        return mainStatus;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
        subject.notifyObservers();
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
        subject.notifyObservers();
    }

    public String getAdditionNotes() {
        return additionNotes;
    }

    public void setAdditionNotes(String additionNotes) {
        this.additionNotes = additionNotes;
        subject.notifyObservers();
    }
}
