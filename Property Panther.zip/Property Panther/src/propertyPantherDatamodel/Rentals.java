/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

/**
 *
 * @author Tom
 */
public class Rentals {
    
    private User user;
    private Property property;
    private int duration;
    
    // empty constructor
    public Rentals(){
        this.user = null;
        this.property = null;
        // default 1 year rental??
        this.duration = 365;
    }
    
    
    public Rentals(User user, Property property, int duration){
        this.user = user;
        this.property = property;
        this.duration = duration;
    }
    
    
    
    
    
    
    
    
}
