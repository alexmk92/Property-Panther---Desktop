/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package propertyPantherDatamodel;

import java.io.Serializable;

/**
 *
 * @author Tom
 */
public class User implements Serializable{
    
    protected String forename;
    protected String surname;
    protected String email;
    protected String number;
    
    
    public User() {
        this.forename = "UNKNOWN";
        this.surname = "UNKNOWN";
    }
    
    public User(String forename, String surname, String email, String number){
        this.forename = forename;
        this.surname = surname;
        this.email = email;
        this.number = number;
    }
    
    public String getName(){
        String result = "UNKNOWN";
        
        if(null != this.forename && null != this.surname){
            result = this.surname + ", " + this.forename;
        }
        return result;
    }
    
    public String getAllDetails(){
        String result = "UNKNOWN";
        
        if(null != this.forename && null != this.surname && null != this.email && null != this.number){
            result = this.surname + ", " + this.forename + "email: " + this.email + "Telephone Number: " + this.number;
        }
        return result;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
    
    
}
